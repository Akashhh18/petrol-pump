# Database-Management-System-for-a-Fuel-Bulk-Depot
A simple html, php, javascript web app

# To run in your local machine in localhost
1. Clone or download .zip file to your local machine <br /> 
2. Copy folder WebApp to wamp64/www directory <br />
3. Create a database named 'petroleum_bulk_depot' using phpmyadmin <br />
4. Import petroleum_bulk_depot.sql in Database directory <br />
5. In browser address bar type localhost/WebApp/user.php
